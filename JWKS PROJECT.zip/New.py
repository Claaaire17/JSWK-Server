from flask import Flask, jsonify, request
import jwt
from cryptography.hazmat.primitives.asymmetric import rsa
from cryptography.hazmat.primitives import serialization
from datetime import datetime, timedelta
import uuid
import base64

app = Flask(__name__)

# Store keys in memory
keys = []

# Function to convert integers to base64url-encoded string
def to_base64url(n):
    return base64.urlsafe_b64encode(n.to_bytes((n.bit_length() + 7) // 8, 'big')).decode('utf-8').rstrip("=")

# Extract the modulus and exponent from the RSA public key
def get_jwks_key_data(public_key):
    public_numbers = public_key.public_numbers()
    modulus = public_numbers.n
    exponent = public_numbers.e
    return {
        "n": to_base64url(modulus),
        "e": to_base64url(exponent)
    }

# Generate RSA key pair
def generate_rsa_key():
    private_key = rsa.generate_private_key(
        public_exponent=65537,
        key_size=2048
    )
    public_key = private_key.public_key()

    # Serialize the private key
    private_key_pem = private_key.private_bytes(
        encoding=serialization.Encoding.PEM,
        format=serialization.PrivateFormat.TraditionalOpenSSL,
        encryption_algorithm=serialization.NoEncryption()
    )

    # Serialize the public key
    public_key_pem = public_key.public_bytes(
        encoding=serialization.Encoding.PEM,
        format=serialization.PublicFormat.SubjectPublicKeyInfo
    )

    # Assign unique kid and set expiry
    key_id = str(uuid.uuid4())  # Generate a unique key id
    expiry_date = datetime.utcnow() + timedelta(hours=1)  # 1 hour expiry

    return {
        "kid": key_id,
        "private_key": private_key_pem.decode('utf-8'),
        "public_key": public_key,
        "expiry": expiry_date
    }

# Function to filter expired keys
def get_valid_keys():
    now = datetime.utcnow()
    return [key for key in keys if key['expiry'] > now]

# JWKS endpoint to serve public keys in JWKS format
@app.route('/.well-known/jwks.json', methods=['GET'])
def jwks():
    valid_keys = get_valid_keys()
    jwks_keys = [{
        "kid": key["kid"],
        "kty": "RSA",
        "use": "sig",
        "alg": "RS256",
        "n": get_jwks_key_data(public_key=key['public_key'])['n'],
        "e": get_jwks_key_data(public_key=key['public_key'])['e']
    } for key in valid_keys]
    
    return jsonify({"keys": jwks_keys})

# Authentication endpoint that returns an unexpired or expired signed JWT
@app.route('/auth', methods=['POST'])
def auth():
    expired = request.args.get('expired')
    
    # Handle expired key signing
    if expired:
        # Pick the first expired key (mock expired)
        chosen_key = keys[0]
        exp_time = datetime.utcnow() - timedelta(hours=1)  # Set expired time
    else:
        valid_keys = get_valid_keys()
        if not valid_keys:
            return jsonify({"error": "No valid keys available"}), 400
        chosen_key = valid_keys[0]
        exp_time = datetime.utcnow() + timedelta(hours=1)  # Set future expiry

    payload = {
        "user": "mock_user",
        "exp": exp_time  # Add expiration time to payload
    }
    token = jwt.encode(payload, chosen_key['private_key'], algorithm="RS256", headers={"kid": chosen_key['kid']})
    
    return jsonify({"token": token})

if __name__ == "__main__":
    # Generate a few keys to serve
    for _ in range(2):
        keys.append(generate_rsa_key())
    
    # Run the Flask app on port 8080
    app.run(port=8080)
